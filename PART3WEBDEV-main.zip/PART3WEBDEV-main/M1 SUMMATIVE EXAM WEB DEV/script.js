function changeBackground() {
    const body = document.querySelector('body');
    const currentColor = body.style.backgroundColor;

    // Switch between different background themes
    if (currentColor === 'rgb(0, 0, 0)') {
        body.style.backgroundColor = '#2a2a2a'; // Darker gray
        body.style.color = '#fff'; // Keep white text
    } else {
        body.style.backgroundColor = '#000'; // Black
        body.style.color = '#fff'; // White text
    }
}

function toggleProjects() {
    const projectsSection = document.getElementById('projects');
    if (projectsSection.style.display === 'none' || projectsSection.style.display === '') {
        projectsSection.style.display = 'block'; // Show the section
    } else {
        projectsSection.style.display = 'none'; // Hide the section
    }
}
