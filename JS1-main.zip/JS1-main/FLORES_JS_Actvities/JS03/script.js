document.getElementById('passwordForm').addEventListener('submit', function(event) {
    event.preventDefault();
    var newPassword = document.getElementById('new-password').value;
    var confirmPassword = document.getElementById('confirm-password').value;
    var notification = document.getElementById('notification');

    if (newPassword === confirmPassword) {
        notification.textContent = 'Password successfully changed!';
        notification.className = 'notification success';
    } else {
        notification.textContent = 'Passwords do not match!';
        notification.className = 'notification error';
    }

    notification.style.display = 'block';
});
