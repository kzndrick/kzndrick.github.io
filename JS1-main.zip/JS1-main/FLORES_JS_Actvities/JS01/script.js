let count = 0; 
const countElement = document.getElementById('count');
const countButton = document.getElementById('countButton');


countButton.addEventListener('click', () => {
    count++; 
    countElement.textContent = count; 
});
