document.getElementById('calculateBtn').addEventListener('click', () => {
    const startDate = new Date(document.getElementById('startDate').value);
    const endDate = new Date(document.getElementById('endDate').value);
    const result = document.getElementById('result');

    if (isNaN(startDate) || isNaN(endDate)) {
        result.style.color = 'red';
        result.textContent = 'Please select valid dates.';
        return;
    }

    const timeDifference = endDate - startDate;
    if (timeDifference < 0) {
        result.style.color = 'red';
        result.textContent = 'End date must be after the start date.';
        return;
    }

    const dayDifference = timeDifference / (1000 * 60 * 60 * 24);
    result.style.color = 'green';
    result.textContent = `The difference is ${dayDifference} days.`;
});
